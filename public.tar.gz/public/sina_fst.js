(function(root) {
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.crossOrigin = 'anonymous';
    script.src = '//cheka.biz.weibo.com/index';
    script.onerror = function() {
        var request = new XMLHttpRequest();
        var web_url = window.encodeURIComponent(window.location.href);
        var url = '//cheka.biz.weibo.com/v1/error';
        request.open('GET', url, true);
        request.send({
            url: web_url,
            message: '404',
            name: '__SDK_CDN__',
            detail: {},
        });
    };
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(script, s);
})(window);
