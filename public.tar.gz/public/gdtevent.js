!(function(g, d, t, e, v, n, s) {
    if (g.gdt) return;
    v = g.gdt = function() {
        v.tk ? v.tk.apply(v, arguments) : v.queue.push(arguments);
    };
    v.queue = [];
    n = d.createElement(t);
    n.async = !0;
    n.src = e;
    s = d.getElementsByTagName(t)[0];
    s.parentNode.insertBefore(n, s);
})(window, document, 'script', '//qzonestyle.gtimg.cn/qzone/biz/gdt/dmp/user-action/gdtevent.min.js');
